choco install git
Install-Module posh-git -Scope AllUsers -Force 
Import-Module posh-git
Add-PoshGitToProfile -AllHosts